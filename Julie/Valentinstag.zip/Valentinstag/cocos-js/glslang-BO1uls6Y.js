System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/glslang-MzD-IByI.wasm")}}}));
